var express = require('express');
var fs = require("fs");
const solc = require('solc');
var Web3 = require('web3');
var web3 = new Web3();
var app = express();
web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
var contractaddress;

//////////////////////////////////////////////////////////////////////////Deployingcontracthere/////////////////////////////////////////////////////////////////////////////////////
var source = fs.readFileSync('./contracts/sandeep.sol', 'utf8');
// let compiledContract = solc.compile(source, 1);
var output = solc.compile(source, 1); // 1 activates the optimiser
var abi;
var bytecode;
for (var contractName in output.contracts) {
    bytecode = output.contracts[contractName].bytecode;
    abi = output.contracts[contractName].interface;
}
var MyContract = web3.eth.contract(JSON.parse(abi));
var gasEstimate = web3.eth.estimateGas({ data: bytecode });
var untitled_sandeep = MyContract.new({
    from: web3.eth.accounts[0],
    data: bytecode,
    gas: gasEstimate
}, function(e, contract) {
    console.log(e, contract);
    if (typeof contract.address !== 'undefined') {
        console.log('Contract mined! address: ' + contract.address + ' transactionHash: ' + contract.transactionHash);
        contractaddress = contract.address;
    }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

app.get('/', function(req, res) {
    res.send("Hello world!");
});

app.get('/sandeep', function(req, res) {
    var x = MyContract.at(contractaddress).a();
    res.send(x);
});

app.listen(3000);